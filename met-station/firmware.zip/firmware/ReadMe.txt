How do I get a .srec file into my unit?


Find the project and data files in:
\\fileserv\CommonNokes\ENGSHARE\Satlink3\Alpha_Firmware
a.k.a. K:\ENGSHARE\Satlink3\Alpha_Firmware                    

Run Segger j-flash application
File-> Open project -> choose file boot_intput_test.jflash

File-> Open data file ->  Bootloader_648.srec
Target -> Erase chip (may not be necessary)
Target -> program & verify

File -> Open data file -> SL3EmbActual_648.srec
Target -> program & verify

Target -> Start Application OR Hard reset the unit

Check LEDs for activity as verification of application running