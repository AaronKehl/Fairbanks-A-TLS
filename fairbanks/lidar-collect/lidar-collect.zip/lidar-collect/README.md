# Lidar Collect

Refer to the [wiki](https://github.com/FRF-Remote-Sensing/LidarCollect/wiki) for installation instructions and usage documentation.
