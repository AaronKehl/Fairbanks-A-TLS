#!/bin/bash

# User defined variables
COLLECT_EXE=/home/tristan/pier/lidar/LidarCollect-build/LidarCollect
DATA_DIR=/home/tristan/pier/lidar/LidarCollect-build/testing/

# Scanner variables
SCANNER_IP=192.168.0.13
STATUS_FILE=$DATA_DIR/scanner-status.txt
ERROR_FILE=$DATA_DIR/scanner-errors.txt

# Get the current datestring and create a folder
DATE_STR=`date +%Y%m%d-%H%M-%S`
OUT_DIR=$DATA_DIR/$DATE_STR
mkdir $OUT_DIR

# Do some test scans
$COLLECT_EXE --ip $SCANNER_IP --frame 0 30 130 0.1 0 360 0.1 fine --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE
sleep 10
$COLLECT_EXE --ip $SCANNER_IP --frame 0 30 130 0.2 0 360 0.2 medium --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE
sleep 10
$COLLECT_EXE --ip $SCANNER_IP --frame 0 30 130 0.4 0 360 0.4 coarse --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE
sleep 10
$COLLECT_EXE --ip $SCANNER_IP --line 0 30 130 0.2 180 30 short --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE
sleep 10
$COLLECT_EXE --ip $SCANNER_IP --line 0 30 130 0.2 180 60 long --dir $OUT_DIR --log --status $STATUS_FILE --warnings $ERROR_FILE
