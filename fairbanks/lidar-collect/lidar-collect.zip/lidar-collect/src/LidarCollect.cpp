#include <riegl/ctrllib.hpp>
#include <riegl/scanlib.hpp>
#include <iostream>
#include <string>
#include <unistd.h>

#include "../include/globals.h"
#include "../include/io/InputParser.h"
#include "../include/scanners/VZ1000.h"


std::string datestring_now()
{
	time_t curr_time;
	std::time(&curr_time);
	struct tm * timeinfo = std::localtime(&curr_time);
	char date_string_char [50];
	std::strftime(date_string_char, 50, "%Y%m%d-%H%M-%S", timeinfo);
	return std::string(date_string_char);
}

void write_status_file(std::string filename, std::string pre_or_post_scan, frf::VZ1000 *scanner)
{
	// Open the scanner status file
	std::ofstream status_file (filename, std::ios::out | std::ios::ate | std::ios::app);

	// Check that the file was opened properly
	if (status_file.is_open()) {

		// Check for an empty file
		if (status_file.tellp() == 0) {

			// Write the file header
			status_file << std::setw(STATUS_WIDTH + 1) << std::left << "COMPUTER_TIME" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "PRE_POST_SCAN" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "FILE_DATE_STRING" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "INSTRUMENT_ID" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "SCAN_TYPE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "ATMOSPHERIC_HUMIDITY" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "ATMOSPHERIC_PRESSURE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "ATMOSPHERIC_TEMPERATURE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "MEMORY_AVAILABLE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "BATTERY_CHARGE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "BATTERY_VOLTAGE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "DEVICE_TEMPERATURE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "GPS_MODE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "GPS_STATUS" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "GPS_TOP_VOLTAGE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "LASER_PRR" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "LASER_PRR_MEASURED" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "NEAR_RANGE_ENABLED" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "POWER_SUPPLY" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "REDUCED_QUALITY_ENABLED" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "SCANNER_DATE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "SCANNER_TIME" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "SUPPLIED_VOLTAGE" <<
						   std::setw(STATUS_WIDTH + 1) << std::left << "OUTPUT_DIRECTORY" << std::endl;
		}

		// Get scan type
		std::string scan_type = "NONE";
		if (scanner->scan_type() == frf::VZ1000::FRAME) scan_type = "FRAME";
		if (scanner->scan_type() == frf::VZ1000::FRAMESEQ) scan_type = "FRAMESEQ";
		if (scanner->scan_type() == frf::VZ1000::LINE) scan_type = "LINE";

		// Write data to file
		status_file << std::setw(STATUS_WIDTH) << std::left << datestring_now() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << pre_or_post_scan << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->datestring() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->instrument_identifier() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scan_type << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->atmospheric_humidity() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->atmospheric_pressure() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->atmospheric_temperature() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->available_memory_internal() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->battery_charge_state() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->battery_supply_voltage() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->device_temperature() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->gps_mode() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->gps_status() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->gps_top_supply_voltage() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->laser_prr() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->laser_prr_measured() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->near_range_enabled() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->power_supply() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->reduced_quality_enabled() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->scanner_date() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->scanner_time() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->supplied_voltage() << ' ' <<
					   std::setw(STATUS_WIDTH) << std::left << scanner->output_directory() << std::endl;

		// Close the data file
		status_file.close();

	}
}

void write_warnings_file(std::string filename, std::string pre_or_post_scan, frf::VZ1000 *scanner)
{
	// Open the scanner warnings log file
	std::ofstream warnings_file (filename, std::ios::out | std::ios::ate | std::ios::app);

	if (warnings_file.is_open()) {

		// Check for an empty file
		if (warnings_file.tellp() == 0) {

			// Write the file header
			warnings_file << std::setw(STATUS_WIDTH + 1) << std::left << "COMPUTER_TIME" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "PRE_POST_SCAN" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "FILE_DATE_STRING" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "INSTRUMENT_ID" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "SCAN_TYPE" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "ERROR_COUNT" <<
							 std::setw(STATUS_WIDTH + 1) << std::left << "ERROR_LIST" << std::endl;

		}

		// Get errors and warnings
		std::vector<std::string> errors = scanner->error_list();

		// Get scan type
		std::string scan_type = "NONE";
		if (scanner->scan_type() == frf::VZ1000::FRAME) scan_type = "FRAME";
		if (scanner->scan_type() == frf::VZ1000::FRAMESEQ) scan_type = "FRAMESEQ";
		if (scanner->scan_type() == frf::VZ1000::LINE) scan_type = "LINE";

		// Write data
		warnings_file << std::setw(STATUS_WIDTH) << std::left << datestring_now() << ' ' <<
						 std::setw(STATUS_WIDTH) << std::left << pre_or_post_scan << ' ' <<
						 std::setw(STATUS_WIDTH) << std::left << scanner->datestring() << ' ' <<
						 std::setw(STATUS_WIDTH) << std::left << scanner->instrument_identifier() << ' ' <<
						 std::setw(STATUS_WIDTH) << std::left << scan_type << ' ' <<
						 std::setw(STATUS_WIDTH) << std::left << scanner->error_count() << ' ';

		for (int i=0; i<errors.size(); ++i) {
			warnings_file << errors[i] << ';';
		}

		warnings_file << std::endl;

		// Close the data file
		warnings_file.close();

		// Acknowledge errors and warnings
		scanner->acknoledge_errors();
		scanner->acknowledge_warnings();
	}
}

void log_everything_else(frf::VZ1000 *scanner)
{
	scanner->atmospheric_pressure_sl();
	scanner->camera_exposure_mode();
	scanner->camera_exposure_time();
	scanner->camera_image_size();
	scanner->camera_lens_aperture();
	scanner->camera_model();
	scanner->camera_white_balance_mode();
	scanner->height_above_msl();
	scanner->lines_per_second();
	scanner->measurement_program();
	scanner->measurement_status();
	scanner->phi_current_angle();
	scanner->phi_increment();
	scanner->phi_speed();
	scanner->phi_start_angle();
	scanner->phi_stop_angle();
	scanner->requested_number_scans();
	scanner->requested_phi_increment();
	scanner->requested_phi_start_angle();
	scanner->requested_phi_stop_angle();
	scanner->requested_theta_increment();
	scanner->requested_theta_start_angle();
	scanner->requested_theta_stop_angle();
	scanner->scan_estimated_duration();
	scanner->scan_progress();
	scanner->scan_time_elapsed();
	scanner->theta_increment();
	scanner->theta_park_angle();
	scanner->theta_speed();
	scanner->theta_start_angle();
	scanner->theta_stop_angle();
}

int main(int argc, char* argv[])
{
	// Parse input and build scanner
	frf::InputParser parser;
	frf::VZ1000* scanner = parser.build_scanner(argc, argv);
	if (scanner) {

		// Try to connect to the scanner (creates the datestring)
		scanner->connect();

		// Check for scanner status log file
		if (parser.log_status())
			write_status_file(parser.status_file(), "PRE", scanner);

		// Check for scanner warnings log file
		if (parser.log_warnings())
			write_warnings_file(parser.warnings_file(), "PRE", scanner);

		// For now, we'll include everything else in the scan info file,
		// but I'd like to be able to group outputs by category (e.g. gps,
		// camera, power, etc.) and have flags available to print/log
		// these groups individually or print/log everything, like we're
		// doing here
		log_everything_else(scanner);

		// Perform the scan
		scanner->start_scanning();

		// Check for scanner status log file
		if (parser.log_status())
			write_status_file(parser.status_file(), "POST", scanner);

		// Check for scanner warnings file
		if (parser.log_warnings())
			write_warnings_file(parser.warnings_file(), "POST", scanner);

	}

	std::cout << std::endl;
	return 0;
}
