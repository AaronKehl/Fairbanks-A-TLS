#include "../../include/scanners/VZ1000.h"

namespace frf {

	VZ1000::VZ1000(std::string ip_address, VerboseLevel verbose_level)
	{
		// Start out not connected with dump logging disabled
		is_connected_ = false;
		is_logging_enabled_ = false;

		// Store the ip address
		ip_address_ = ip_address;

		// Store the verbosity level
		verbose_level_ = verbose_level;

		// No scan type initially set
		scan_type_ = NONE;

		// Linescan initially set to 10 seconds
		line_time_ = 10;
	}


	VZ1000::~VZ1000()
	{
		// Disconnect from the scanner
		disconnect();

		// Close files
		if (log_scan_.is_open()) log_scan_.close();
	}


	/**
	 * @brief VZ1000::connect Attempts to connect to the scanner
	 * if not already connected.
	 * @return true if connected to the scanner, false otherwise
	 */
	bool VZ1000::connect()
	{
		if (!is_connected()) {

			try {

				// Build the datestring used for this session
				build_datestring();

				// Attempt to open the log file
				open_log_file_scan();

				// Log the connect
				log("CONNECT", ip_address_, "LASERS!");

				// Connect to the scanner
				scanner.open(ip_address_);
				is_connected_ = true;

			}

			catch (std::exception& e) {

				// Log the error
				log("ERROR", "CONNECT", e.what());

				// Unable to connect
				is_connected_ = false;

			}
		}

		return is_connected();
	}


	void VZ1000::disconnect()
	{
		if (is_connected()) {

			try {

				// Log disconnect
				log("DISCONNECT", ip_address_, "LASERS!");

				// Disconnect from scanner
				scanner.close();

				// Check for dump logging
				if (!log_file_dump_.empty())
					scanner.stop_logging();

				is_connected_ = false;
			}

			catch (std::exception& e) {

				log("ERROR", "DISCONNECT", e.what());

			}
		}

		// Check for logging - do it here because it's possible we
		// were never able to connect to the scanner and we still
		// want to write the log file if that is the case
		if (is_logging_enabled_) {

			// If no scan was performed but logging was enabled, we'll
			// need to open the log file and dump the buffer into it
			open_log_file_scan(true);

			// Close the log file
			if (log_scan_.is_open())
				log_scan_.close();

		}
	}


	void VZ1000::start_scanning()
	{

		// Make sure scan parameters were set
		if (scan_type_ == NONE) {
			log("INFO", "No scan parameters set", "", true);
			return;
		}

		// Make sure scanner isn't busy
		abort_scanning();

		// Make sure the scanner is all caught up
		wait_for_scanner();

		// Build the output filename
		time_t start_time, curr_time;
		std::time(&start_time);
		std::string filename = build_filename(scan_type_, "rxp");

		// Create the output file
		std::ofstream outfile (output_directory_ + filename, std::ios::binary|std::ios::out);
		set_property("STOR_MEDIA", "0");

		if (outfile.is_open()) {

			// Output status
			if (verbose_level_ >= VERBOSE) {
				struct tm * timeinfo = std::localtime(&start_time);
				char datestring[50];
				std::strftime(datestring, 50, "%b %d, %Y  %r", timeinfo);
				log("SCAN", "Starting scan at:", std::string(datestring), true);
			}

			// Start the scanner
			execute_command("MEAS_START");

			// Create the scanlib connection for receiving data packets
			std::string connection_string = "rdtp://" + ip_address_ + "/current";
			std::shared_ptr<scanlib::basic_rconnection> connection = scanlib::basic_rconnection::create(connection_string);

			try {

				// Open the connection
				connection->open();

				// Create variables for reading
				scanlib::basic_rconnection::size_type bytes_read = 0;
				scanlib::basic_rconnection::size_type total_read = 0;
				char data[8192];

				// If we're doing a line scan, collect until the requested
				// amount of time has elapsed;
				if (scan_type_ == LINE) {

					while ((bytes_read = connection->readsome(data, 8192)) != 0) {

						// Get the current time
						std::time(&curr_time);

						// Write data packet to the file
						outfile.write(data, bytes_read);
						total_read += bytes_read;

						// Check if it's time to stop the collect
						if (std::difftime(curr_time, start_time) > line_time_) {

							// Log shutdown request
							log("REQUEST", "FINISH", "SCAN");

							// Tell the scanner to stop sending data
							connection->request_shutdown();
						}

					}
				}

				// If we're doing a framescan, collect until finished
				else {

					while ((bytes_read = connection->readsome(data, 8192)) != 0) {

						// Write data packet to file
						outfile.write(data, bytes_read);
						total_read += bytes_read;

						// Check if it's time to stop the collect
						std::string is_busy = execute_command_silent("MEAS_BUSY", "0");
						if (is_busy == "0" || is_busy == "ERR") {

							// Log shutdown request
							log("REQUEST", "FINISH", "SCAN");

							// Tell the scanner to stop sending data
							connection->request_shutdown();
						}
					}
				}

				// Get the current time
				std::time(&curr_time);

				// Close the buffer connection
				connection->close();

				// Finished scanning, save the file
				outfile.close();

				// Stop the scanner and clear buffer
				abort_scanning();

				// Output status
				if (verbose_level_ >= VERBOSE) {
					struct tm * timeinfo = std::localtime(&curr_time);
					char datestring[50];
					std::strftime(datestring, 50, "%b %d, %Y  %r", timeinfo);
					log("SCAN", "Scan finished at:", std::string(datestring), true);
				}
			}

			catch (std::exception& e) {

				log("ERROR", "SCAN", e.what());

			}
		}
	}


	void VZ1000::wait_for_scanner()
	{
		// Check for at least verbose output
		log("INFO", "Waiting for scanner...", "", true);

		// Wait for the scanner to finish what it's doing
		execute_command("MEAS_BUSY", "1");
	}


	std::string VZ1000::framescan(int program, float theta_start, float theta_end, float theta_inc, float phi_start, float phi_end, float phi_inc, int num_seq)
	{
		// Set the measurement program
		execute_command("MEAS_SET_PROG", std::to_string(program));

		// Build the command string
		std::stringstream cmd;
		cmd << theta_start << ',' <<
			   theta_end << ',' <<
			   theta_inc << ',' <<
			   phi_start << ',' <<
			   phi_end << ',' <<
			   phi_inc;

		// Check for sequential or single
		if (num_seq == 1) {

			// Store scan type
			scan_type_ = FRAME;

			// Attempt to open the log file
			if (is_logging_enabled_)
				open_log_file_scan();

			// Run command
			return execute_command("SCN_SET_RECT_FOV", cmd.str());
		}

		else {

			// Add number of scans
			cmd << ',' << num_seq;

			// Store scan type
			scan_type_ = FRAMESEQ;

			// Attempt to open the log file
			if (is_logging_enabled_)
				open_log_file_scan();

			// Run command
			return execute_command("SCN_SET_RECT_FOV_SEQ", cmd.str());
		}
	}


	std::string VZ1000::linescan(int program, float theta_start, float theta_end, float theta_inc, float phi, float duration_seconds)
	{
		// Set the measurement program
		execute_command("MEAS_SET_PROG", std::to_string(program));

		// Build the command string
		std::stringstream cmd;
		cmd << theta_start << ',' <<
			   theta_end << ',' <<
			   theta_inc << ',' <<
			   phi;

		// Save the linescan time
		line_time_ = duration_seconds;

		// Save the scan type
		scan_type_ = LINE;

		// Attempt to open the log file
		if (is_logging_enabled_)
			open_log_file_scan();

		// Run command
		return execute_command("SCN_SET_LINE_SCAN", cmd.str());
	}


	/**
	 * @brief VZ1000::inclination Get device inclination angles
	 * @param mode One of:
	 *  - "0": SINGLE_AT_CURRENT_POS
	 *  - "1": AVERAGE_AT_CURRENT_POS
	 *  - "2": AVERAGE_WITH_CONTINUOUS_ROTATION
	 *  - "3": AVERAGE_AT_CERTAIN_POSITIONS
	 * @return "ROLL, PITCH"
	 */
	std::string VZ1000::inclination(std::string mode)
	{
		return execute_command("INCL_ACQUIRE", mode);
	}


	/**
	 * @brief VZ1000::position_estimate Get device position data
	 * @param mode One of:
	 *  - "0": SINGLE_AT_CURRENT_POS
	 *  - "1": AVERAGE_AT_CURRENT_POS
	 *  - "2": AVERAGE_WITH_CONTINUOUS_ROTATION
	 *  - "3": AVERAGE_AT_CERTAIN_POSITIONS
	 * @param update_hdr Update scanner position in rxp header, one of:
	 *  - "0": NO
	 *  - "1": YES
	 * @return "LONGITUDE, LATITUDE, HEIGHT (above ellipsoid), HEIGHT (above MSL),
	 * ROLL, PITCH, YAW, GPS HORIZONTAL ACCURACY, GPS VERTICAL ACCURACY,
	 * ROLL ACCURACY, PITCH ACCURACY, YAW ACCURACY"
	 */
	std::string VZ1000::position_estimate(std::string mode, std::string update_hdr)
	{
		std::string args = mode + ',' + update_hdr;
		return execute_command("POS_ESTIM", args);
	}


	void VZ1000::set_atmospheric_humidity(int percent_humidity)
	{
		set_property("ATMOS_REL_HUMID", std::to_string(percent_humidity));
	}


	void VZ1000::set_atmospheric_pressure_sl(int pressure_mbar)
	{
		set_property("ATMOS_PRESSURE", std::to_string(pressure_mbar));
	}


	void VZ1000::set_atmospheric_temperature(int degrees_c)
	{
		set_property("ATMOS_TEMP", std::to_string(degrees_c));
	}


	void VZ1000::set_camera_exposure_mode(int mode)
	{
		set_property("CAM_EXPOSURE_MODE", std::to_string(mode));
	}


	void VZ1000::set_camera_exposure_time(float seconds)
	{
		set_property("CAM_EXPOSURE_TIME", std::to_string(seconds));
	}


	void VZ1000::set_camera_lens_aperture(float aperture)
	{
		set_property("CAM_LENS_APERTURE", std::to_string(aperture));
	}


	void VZ1000::set_camera_white_balance_mode(int mode)
	{
		set_property("CAM_WHITE_BALANCE_MODE", std::to_string(mode));
	}


	void VZ1000::set_gps_mode(int mode)
	{
		set_property("GPS_MODE", std::to_string(mode));
	}


	void VZ1000::set_gps_voltage(float voltage)
	{
		set_property("GPS_EXT_SUPPLY_VOLTAGE", std::to_string(voltage));
	}


	void VZ1000::set_near_range_enabled(bool is_enabled)
	{
		set_property("FILT_NEAR_RNG_ACTIVE", is_enabled ? "1" : "0");
	}


	void VZ1000::set_reduced_quality_enabled(bool is_enabled)
	{
		set_property("FILT_REDUCED_QUALITY_ENABLE", is_enabled ? "1" : "0");
	}


	void VZ1000::set_file_identifier(std::string identifier)
	{
		file_identifier_ = identifier;

		// Attempt to open the log file
		if (is_logging_enabled_)
			open_log_file_scan();
	}


	void VZ1000::set_log_file_dump(std::string filename)
	{
		log_file_dump_ = filename;
		if (!log_file_dump_.empty())
			scanner.start_logging(output_directory_ + log_file_dump_);
	}


	void VZ1000::set_logging_enabled(bool logging_enabled)
	{
		is_logging_enabled_ = logging_enabled;
	}


	void VZ1000::set_output_directory(std::string fullpath)
	{
		output_directory_ = fullpath + '/';
	}


	void VZ1000::error(std::string error_string)
	{
#ifndef _WIN32
		std::cout << RED;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[ERROR]";
		std::cout << error_string << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void VZ1000::status(std::string status_string_1, std::string status_string_2, std::string status_string_3)
	{
#ifndef _WIN32
		std::cout << GREEN;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << status_string_1;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
		std::cout << std::setw(CMD_WIDTH_2) << std::left << status_string_2
				  << status_string_3 << std::endl;
	}


	void VZ1000::warn(std::string warning_string)
	{
#ifndef _WIN32
		std::cout << YELLOW;
#endif
		std::cout << std::setw(CMD_WIDTH_1) << std::left << "[WARNING]";
		std::cout << warning_string << std::endl;
#ifndef _WIN32
		std::cout << NORMAL;
#endif
	}


	void VZ1000::build_datestring()
	{
		time_t curr_time;
		std::time(&curr_time);
		struct tm * timeinfo = std::localtime(&curr_time);
		char date_string_char [50];
		std::strftime(date_string_char, 50, "%Y%m%d-%H%M-%S", timeinfo);
		date_string_ = std::string(date_string_char);
	}


	std::string VZ1000::build_filename(ScanType type, std::string extension)
	{
		std::stringstream filename;

		if (!date_string_.empty())
			filename << date_string_ << '.';

		if (!file_identifier_.empty())
			filename << file_identifier_ << '.';

		if (type == LINE) filename << "line.";
		if (type == FRAME) filename << "frame.";
		if (type == FRAMESEQ) filename << "frameseq.";

		filename << extension;

		return filename.str();
	}


	std::string VZ1000::execute_command(std::string cmd, std::string args)
	{
		// Make sure we're connected to the scanner
		if (connect()) {

			try {

				// Log action
				log("EXE", cmd, args);

				// Execute the command
				std::string result, status;
				std::vector<std::string> comments;
				scanner.execute_command(cmd, args, &result, &status, &comments);

				// Log results and comments
				log("EXERESULT", cmd, result);
				for (int i=0; i<comments.size(); ++i)
					log("EXECOMMENT", cmd, comments[i]);

				return result;
			}

			catch (std::exception& e) {

				log("ERROR", "EXE", e.what());
				return "ERR";
			}
		}

		return "NOT_CONNECTED";
	}


	std::vector<std::string> VZ1000::execute_command_comments(std::string cmd, std::string args)
	{
		// Make sure we're connected to the scanner
		if (connect()) {

			try {

				// Log action
				log("EXE", cmd, args);

				// Execute the command
				std::string result, status;
				std::vector<std::string> comments;
				scanner.execute_command(cmd, args, &result, &status, &comments);

				// Log results and comments
				log("EXERESULT", cmd, result);
				for (int i=0; i<comments.size(); ++i)
					log("EXECOMMENT", cmd, comments[i]);

				return comments;
			}

			catch (std::exception& e) {

				log("ERROR", "EXE", e.what());
				return std::vector<std::string> (1, "ERROR");
			}
		}

		else {
			return std::vector<std::string> (1, "NOT_CONNECTED");
		}
	}


	std::string VZ1000::execute_command_silent(std::string cmd, std::string args)
	{
		// Make sure we're connected to the scanner
		if (connect()) {

			try {

				// Execute the command
				std::string result;
				scanner.execute_command(cmd, args, &result);

				return result;
			}

			catch (...) {
				return "ERR";
			}
		}

		else {
			return "NOT_CONNECTED";
		}
	}


	std::string VZ1000::get_property(std::string property)
	{
		// Make sure we're connected to the scanner
		if (connect()) {

			try {

				// Get the value
				std::string value;
				scanner.get_property(property, value);

				// Log the value
				log("GET", property, value);

				return value;
			}

			catch (std::exception& e) {

				log("ERROR", "GET", e.what());
				return "ERR";
			}
		}

		else {
			return "NOT_CONNECTED";
		}
	}


	void VZ1000::log(std::string col1, std::string col2, std::string col3, bool exclude)
	{
		// Check for scan log
		if (is_logging_enabled_ && exclude != true) {
			if (log_scan_.is_open()) {
				log_scan_ << std::setw(LOG_WIDTH_1) << std::left << col1
						 << std::setw(LOG_WIDTH_2) << std::left << col2
						 << col3 << std::endl;
			} else {
				std::stringstream log_message;
				log_message << std::setw(LOG_WIDTH_1) << std::left << col1
							<< std::setw(LOG_WIDTH_2) << std::left << col2
							<< col3 << std::endl;
				log_buffer_.push_back(log_message.str());
			}
		}

		// Check for non-silent output
		if (verbose_level_ > SILENT) {

			// Always print errors
			if (col1 == "ERROR")
				error(col3);

			// Always print warnings
			if (col1 == "WARNING")
				warn(col3);

			// Only print scans, customs, connects, and disconnects if at least verbose
			if (verbose_level_ > QUIET) {

				if (col1 == "SCAN")
					status("[SCAN]", col2, col3);
				if (col1 == "INFO")
					status("[STATUS]", col2, col3);
				if (col1 == "CONNECT")
					status("[CONNECT]", "Connecting to scanner at:", col2);
				if (col1 == "DISCONNECT")
					status("[DISCONNECT]", "Disconnecting from scanner");
			}

			// Only print sets, gets, and exes if loud
			if (verbose_level_ > VERBOSE) {

				if (col1 == "SET")
					status("[SET]", col2, col3);
				if (col1 == "GET")
					status("[GET]", col2, col3);
				if (col1 == "EXE")
					status("[EXE]", col2, col3);
				if (col1 == "EXERESULT")
					status("[EXERESULT]", col2, col3);
				if (col1 == "EXECOMMENT")
					status("[EXECOMMENT]", col2, col3);
			}
		}
	}


	void VZ1000::open_log_file_scan(bool force)
	{
		// Make sure the file isn't already open
		if (!log_scan_.is_open()) {

			// Make sure we've got everything we need to build the full filename
			bool have_date_string = !date_string_.empty();
			bool have_file_identifier = !file_identifier_.empty();
			bool have_scan_type = scan_type_ != NONE;

			if (force || (have_date_string && have_file_identifier && have_scan_type)) {

				// Build the filename
				std::string fullpath = output_directory_ + build_filename(scan_type_, "info.txt");

				// Open the file
				log_scan_.open(fullpath);

				// Add the header
				if (log_scan_.is_open()) {
					log("COMMAND", "PROPERTY", "VALUE/RESPONSE");
				}

				// Anything that's been buffer gets dumped into the file
				for (int i=0; i<log_buffer_.size(); ++i)
					log_scan_ << log_buffer_[i];

				// Empty out the buffer
				log_buffer_.clear();
			}
		}
	}


	void VZ1000::set_property(std::string property, std::string value)
	{
		// Make sure we're connected to the scanner
		if (connect()) {

			try {

				// Set the value
				scanner.set_property(property, value);

				// Log the action
				log("SET", property, value);

				// We also want to show the user the values that were
				// actually set by the scanner, so if logging or loud
				// output are set, query the scanner
				if (log_scan_.is_open() || verbose_level_ >= LOUD)
					get_property(property);
			}

			catch (std::exception& e) {

				log("WARNING", "SET", e.what());

			}
		}
	}
}
